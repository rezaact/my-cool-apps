package id.co.hans.sample.server.dao;

public class clsJatuhTempo {
    public String UNITUP ;
    public String KODESIKLIS ;
    public String PERIODE ;
    public String THBL ;
    public String JATUHTEMPO ;
    public String BK1 ;
    public String BK2 ;
    public String BK3 ;
    public String CREATEDON ;
    public String CREATEBY ;
}
