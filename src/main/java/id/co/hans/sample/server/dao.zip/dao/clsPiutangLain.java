package id.co.hans.sample.server.dao;

public class clsPiutangLain {
    public String NoAgenClass =  "";
    public String NoPelClass =  "";
    public String NokonClass =  "";
    public String KodePerClass =  "";
    public String BiayaClass =  "";
    public String KodePetugasClass =  "";
    public String keteranganClass =  "";
    public String NamaPiutangClass =  "";
    public String AtasDasarClass =  "";
    public String RekeningPecahClass =  "";
    public String TglAgendaClass =  "";
    public String NamaPelangganClass =  "";
    public String JalanClass =  "";
    public String NamaJalanClass =  "";
    public String NoBangunanClass =  "";
    public String KodeBangunanClass =  "";
    public String RTClass =  "";
    public String RWClass =  "";
    public String KelurahanDesaClass =  "";
    public String KecamatanClass =  "";
    public String KodyaKabupatenClass =  "";
    public String TeleponClass =  "";
    public String KodePosClass =  "";
    public String FaxClass =  "";
    public String KodeRantingClass =  "";
    public String KodeRantingNumerikClass =  "";
    public String KodeGarduClass =  "";
    public String NoTiangClass =  "";
    public String TaripClass =  "";
    public String DayaClass =  "";
    public String KoGolClass =  "";
    public String MutasiKoreksiClass =  "";
    public String JenisMutasiKoreksiClass =  "";
    public String TglTransaksiClass =  "";
    public String TglJatuhTempoClass =  "";
}
