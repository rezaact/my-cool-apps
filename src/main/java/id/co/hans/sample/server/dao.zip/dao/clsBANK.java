package id.co.hans.sample.server.dao;

public class clsBANK {
    public String KODE_RANTING;
    public String KODE_RANTING_NUMERIK;
    public String KODE_BANK;
    public String NAMA_BANK;
    public String ALAMAT;
    public String JENISBANK;
    public String KODE_GERAK_KELUAR;
    public String PENGELOLA;
    public String REKNO;
    public String BANK;
}
