package id.co.hans.sample.server.dao.impl;


import id.co.hans.sample.server.utility.CommonModule;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ws_CreditNoteDaoImpl {
    public static final Log log = LogFactory.getLog(ws_CreditNoteDaoImpl.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public Map<String, Object> ambilNamaBank(String unitup) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = " select  ";
            sql = sql + "UNITUP, KODE_BANK, NAMA_BANK, ALAMAT, JENISBANK, REKNO, NO_REKENING, PENGELOLA, NO_PKS, PKS_FROMDATE, PKS_ENDDATE, TGLCATAT, CATATBY, TGLUPDATE, UPDATEBY ";
            sql = sql + "from view_banksip3_daftar ";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("ambilNamaBank", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> ambilDataCN(String unitup,
                                           String kdpp, String tglbayar) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = " SELECT  ";
            sql = sql + "UNITUP, KDPP, TGLBAYAR, LEMBAR, RPPTL, RPPPN, RPBPJU, RPTRAFO, RPLAIN, RPMAT, RPTAG, RPBK ";
            sql = sql + "FROM VIEW_CN_AMBILDATA ";
            sql += " where ";
            sql += " kdpp = '" + kdpp + "' ";
            sql += " and tglbayar = '" + tglbayar + "' ";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("ambilDataCN", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> ambilDataCNPengelola(String unitup,
                                                    String kdpengelola, String tglbayar) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = " SELECT  ";
            sql = sql + "UNITUP, TGLBAYAR, LEMBAR, RPPTL, RPPPN, RPBPJU, RPTRAFO, RPLAIN, RPMAT, RPTAG, RPBK ";
            sql = sql + "FROM view_cn_ambildata_pengelola ";
            sql += " where ";
            sql += " kodepengelola = '" + kdpengelola + "' ";
            sql += " and tglbayar = '" + tglbayar + "' ";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("ambilDataCNPengelola", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> ambilDataCNPetugas(String unitup,
                                                  String kdpp, String tglbayar, String ptgbayar) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql =" SELECT  ";
            sql = sql + "UNITUP, KDPP, TGLBAYAR, KDPEMBAYAR AS PTGLUNAS, LEMBAR, RPPTL, RPPPN, RPBPJU, RPTRAFO, RPLAIN, RPMAT, RPTAG, RPBK ";
            sql = sql + "FROM view_cn_ambildataperpetugas ";
            sql += " where ";
            sql += " kdpp = '" + kdpp + "' ";
            sql += " and tglbayar = '" + tglbayar + "' ";
            sql += " and kdpembayar = '" + ptgbayar + "' ";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("ambilDataCNPetugas", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    Map<String, Object> isCNExist(String kdpp, String tglbayar) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql =" SELECT  COUNT(*) AS JML";
            sql += " FROM CNSIP3 ";
            sql += " where ";
            sql += " kdpp = '" + kdpp + "' ";
            sql += " and tgl_pelunasan = '" + tglbayar + "' " ;
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("isCNExist", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }

    Map<String, Object> isCNPengelolaExist(String kdpengelola, String tglbayar) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql =" SELECT  COUNT(*) AS JML";
            sql += " FROM CNSIP3_PENGELOLA ";
            sql += " where ";
            sql += " KODEPENGELOLA = '" + kdpengelola + "' ";
            sql += " and tgl_pelunasan = '" + tglbayar + "' " ;
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("isCNPengelolaExist", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    Map<String, Object> isCNPetugasExist(String kdpp, String tglbayar, String ptglunas) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql =" SELECT  COUNT(*) AS JML";
            sql += " FROM CNSIP3_PETUGAS ";
            sql += " where ";
            sql += " kdpp = '" + kdpp + "' ";
            sql += " and tgl_pelunasan = '" + tglbayar + "' ";
            sql += " and PTGLUNAS = '" + ptglunas + "' " ;
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("isCNPetugasExist", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    Map<String, Object> isCNPetugasExist(String kdpp, String tglbayar) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql =" SELECT  COUNT(*) AS JML";
            sql += " FROM CNSIP3_PETUGAS ";
            sql += " where ";
            sql += " kdpp = '" + kdpp + "' ";
            sql += " and tgl_pelunasan = '" + tglbayar + "' ";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("isCNPetugasExist", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> simpanDataCN(Map<String, Object> ds, Boolean bEdit) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();



            String sql ="Proc_CreditNoteInsert ";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("simpanDataCN", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }

    public Map<String, Object> simpanDataCNPengelola(Map<String, Object> ds, Boolean bEdit) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();



            String sql ="Proc_CNInsertPengelola ";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("simpanDataCNPengelola", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> simpanDataCNPerPetugas(Map<String, Object> ds, Boolean bEdit) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();



            String sql ="Proc_CreditNoteInsertPerPtgLns ";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("simpanDataCNPerPetugas", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> ambilFormatCN() {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();



            String sql ="SELECT * FROM view_cnsip3_daftar";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("ambilFormatCN", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> ambilFormatCNPengelola() {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();



            String sql ="SELECT * FROM view_cnsip3_pll_daftar";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("ambilFormatCNPengelola", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> ambilFormatCNPerPlg() {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();



            String sql ="SELECT * FROM view_cnsip3_daftar_perptglns";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("ambilFormatCNPerPlg", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> ambilRekapCN(String Jenis, String unitup, String kodepp, String tglAwal, String tglAkhir) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();



            String sql =" SELECT UNITUP, KDPP, NO_BATULV06, TGLTRANSAKSI, TRANSAKSIID, TRANSAKSIBY, TGL_PELUNASAN, TGL_SETOR, LEMBAR, RPPTL, BANKRPPTL, CNRPPTL, RPBPJU, BANKRPBPJU, CNRPBPJU, RPPPN, BANKRPPPN, CNRPPPN, RPMAT, BANKRPMAT, CNRPMAT, RPTRAFO, BANKRPTRAFO, CNRPTRAFO, RPLAIN, BANKRPLAIN, CNRPLAIN, RPBK, BANKRPBK, CNRPBK, RPTAG, TGLTRANSAKSIBATAL, TRANSAKSIIDBATAL, TRANSAKSIBATALBY ";
            sql += " FROM view_cnsip3_daftar ";
            sql += " where unitup = '" + unitup + "' ";
            sql += " and kdpp = '" + kodepp + "' ";

            sql += " and tgl_pelunasan >= '" + tglAwal + "' and tgl_pelunasan <= '" + tglAkhir + "' ";
            sql += " order by tgl_pelunasan, tgltransaksi ";


            sql += " and tgl_setor >= '" + tglAwal + "' and tgl_setor <= '" + tglAkhir + "' ";
            sql += " order by tgl_setor, tgltransaksi ";

                sql = " select * from view_cnsip3_perptg ";
            sql += " where to_char(tgl_pelunasan,'yyyyMMdd') >= '" + tglAwal + "' and to_char(tgl_pelunasan,'yyyyMMdd') <= '" + tglAkhir + "' " ;
            sql += " and unitup='" + unitup + "'" ;

            sql += " and kodepp = '" + kodepp + "' " ;

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("ambilRekapCN", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> ambilDataDanaperTglPp(String unitup, String kodepp, String tglAwal, String tglAkhir) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();



            String sql =" SELECT UNITUP, KDPP, TGL_PELUNASAN, LEMBAR_DANA, RPPTL_DANA, RPBPJU_DANA, RPPPN_DANA, RPMAT_DANA, RPTRAFO_DANA, RPLAIN_DANA, RPBK_DANA, RPTAG_DANA, LEMBAR_DATA, RPPTL_DATA, RPBPJU_DATA, RPPPN_DATA, RPMAT_DATA, RPTRAFO_DATA, RPLAIN_DATA, RPBK_DATA, RPTAG_DATA ";
            sql += " FROM VIEW_CNDATADANA_KODEPP ";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("ambilDataDanaperTglPp", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }
}
