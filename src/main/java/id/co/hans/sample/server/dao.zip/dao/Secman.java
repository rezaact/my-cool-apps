package id.co.hans.sample.server.dao;

public class Secman {
    public String GetMD5 (String str) {
        String sRet = "";

        //todo: md5 di secman

        return sRet;
    }
}
