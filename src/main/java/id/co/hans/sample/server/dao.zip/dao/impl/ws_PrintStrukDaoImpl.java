package id.co.hans.sample.server.dao.impl;


import id.co.hans.sample.server.dao.cls_CetakUlang;
import id.co.hans.sample.server.utility.CommonModule;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ws_PrintStrukDaoImpl {
    public static final Log log = LogFactory.getLog(ws_PrintStrukDaoImpl.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    Map<String, Object> cetakRekg12(String tTgKoreksi, String tIdpel, String tBlth, String tNorek) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = " select BLTH, IDPEL, NOPEL, KDGERAKMASUK, KDKOREKSI, TGKOREKSI, STATUS, KDPEMBPP, UNITUP, KOREKSIBY, PEMDA, NAMA, PNJ, NAMAPNJ, NOBANG, KETNOBANG, RT, RW, NODLMRT, KETNODLMRT, LINGKUNGAN, KODEPOS, IDTARIP, TARIP, KDPEMBTRF, ABONMETER, DAYA, KDAYA, KOGOL, SUBKOGOL, FRT, FJN, KDPPJ, UNITKJ, KDINKASO, KDKELOMPOK, TGLJTTEMPO, KDDK, TGLBACA, SLALWBP, SAHLWBP, SLAWBP, SAHWBP, SLAKVARH, SAHKVARH, SKVAMAX, FAKM, FAKMKVARH, FAKMKVAMAX, KWHLWBP, KWHWBP, BLOK3, PEMKWH, KWHKVARH, KELBKVARH, RPLWBP, RPWBP, RPBLOK3, RPKVARH, RPBEBAN, CTTLB, RPTTLB, RPPTL, RPTB, RPPPN, RPBPJU, RPTRAFO, RPSEWATRAFO, RPSEWAKAP, KDANGSA, RPANGSA, KDANGSB, RPANGSB, KDANGSC, RPANGSC, RPMAT, RPPLN, RPTAG, RPPRODUKSI, RPSUBSIDI, RPREDUKSI, RPINSENTIF, RPDISINSENTIF, RPBK1, RPBK2, RPBK3, RPTDLLAMA, RPTDLBARU, RPSELISIH, NOREK, NOAGENDA, FLAGSOPP, FLAGANJA, KDKIRIM, KDTERIMA ";
            sql = " ,BPAKAI1,BPAKAI2,BPAKAI3,BKVAR ";
            sql = " select BLTH, IDPEL, NOPEL, KDGERAKMASUK, KDKOREKSI, TGKOREKSI, STATUS, KDPEMBPP, UNITUP, KOREKSIBY, PEMDA, NAMA, PNJ, NAMAPNJ, NOBANG, KETNOBANG, RT, RW, NODLMRT, KETNODLMRT, LINGKUNGAN, KODEPOS, IDTARIP, TARIP, KDPEMBTRF, ABONMETER, DAYA, KDAYA, KOGOL, SUBKOGOL, FRT, FJN, KDPPJ, UNITKJ, KDINKASO, KDKELOMPOK, TGLJTTEMPO, KDDK, TGLBACA, SLALWBP,SAHLWBP, SLAWBP, SAHWBP, SLAKVARH, SAHKVARH, SKVAMAX, FAKM, FAKMKVARH, FAKMKVAMAX, KWHLWBP, KWHWBP, BLOK3, PEMKWH, KWHKVARH, KELBKVARH, RPLWBP, RPWBP, RPBLOK3, RPKVARH, RPBEBAN, CTTLB, RPTTLB, RPPTL, RPTB, RPPPN, RPBPJU, RPTRAFO, RPSEWATRAFO, RPSEWAKAP, KDANGSA, RPANGSA, KDANGSB, RPANGSB, KDANGSC, RPANGSC, RPMAT, RPPLN, RPTAG, RPPRODUKSI, RPSUBSIDI, RPREDUKSI, RPINSENTIF, RPDISINSENTIF, RPBK1, RPBK2, RPBK3, RPTDLLAMA, RPTDLBARU, RPSELISIH, NOREK, NOAGENDA, FLAGSOPP, FLAGANJA, KDKIRIM, KDTERIMA, ";
            sql = " CETAK, PERIODE, BPAKAI1, BPAKAI2, BPAKAI3, BKVAR, PESAN, TELPPENGADUAN, TGLCETAK,IDPEL AS NO_PELANGGAN";
            sql = " from VIEW_CETAKREKG_12ABCG_TFORM ";
            sql = " where ";
            sql = " idpel = '" + tIdpel + "' ";
            sql = " and tgkoreksi = '" + tTgKoreksi + "' ";
            sql = " and kdpembpp = 'R1' ";
            sql = " and kdgerakmasuk = '12' ";
            sql = " and blth = '" + tBlth + "' ";
            sql = " and norek = '" + tNorek + "' ";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("cetakRekg12", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    Map<String, Object> cetakRekg41(String tTgKoreksi, String tIdpel, String tBlth, String tNorek) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = " select BLTH, IDPEL, NOPEL, KDGERAKMASUK, UPLOADTIME, UPLOADBY, KDGERAKKELUAR, TGLBAYAR, WKTBAYAR, KDPP, KDPEMBAYAR, KDKOREKSI, TGKOREKSI, STATUS, KDPEMBPP, KDPEMBAYARSIP3, UNITUP, PEMDA, NAMA, PNJ, NAMAPNJ, NOBANG, KETNOBANG, RT, RW, NODLMRT, KETNODLMRT, LINGKUNGAN, KODEPOS, IDTARIP, TARIP, KDPEMBTRF, ABONMETER, DAYA, KDAYA, KOGOL, SUBKOGOL, FRT, FJN, KDPPJ, UNITKJ, KDINKASO, KDKELOMPOK, TGLJTTEMPO, KDDK, TGLBACA, SLALWBP, SAHLWBP, SLAWBP, SAHWBP, SLAKVARH, SAHKVARH, SKVAMAX, FAKM, FAKMKVARH, FAKMKVAMAX, KWHLWBP, KWHWBP, BLOK3, PEMKWH, KWHKVARH, KELBKVARH, RPLWBP, RPWBP, RPBLOK3, RPKVARH, RPBEBAN, CTTLB, RPTTLB, RPPTL, RPTB, RPPPN, RPBPJU, RPTRAFO, RPSEWATRAFO, RPSEWAKAP, KDANGSA, RPANGSA, KDANGSB, RPANGSB, KDANGSC, RPANGSC, RPMAT, RPPLN, RPTAG, RPPRODUKSI, RPSUBSIDI, RPREDUKSI, RPINSENTIF, RPDISINSENTIF, RPBK1, RPBK2, RPBK3, RPTDLLAMA, RPTDLBARU, RPSELISIH, NOREK, NOAGENDA, FLAGSOPP, FLAGANJA, KDKIRIM, KDTERIMA, KOREKSIBY ";
            sql = " ,BPAKAI1,BPAKAI2,BPAKAI3,BKVAR ";
            sql = " from VIEW_CETAKREKG_41_TFORM ";
            String Sql = " where ";
            Sql = " idpel = '" + tIdpel + "' ";
            Sql = " and tgkoreksi = '" + tTgKoreksi + "' ";
            Sql = " and kdpembpp = 'R1' ";
            Sql = " and kdgerakmasuk = '41' ";
            Sql = " and blth = '" + tBlth + "' ";
            Sql = " and norek = '" + tNorek + "' ";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("cetakRekg41", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    Map<String, Object> cetakRekg12D(String tKodePetugas,
                                     String tIDPEL,
                                     String tBLTH) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = " SELECT * ";
            sql = " from VIEW_CETAK303_12D ";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("cetakRekg12D", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    Map<String, Object> cetakRekg23(String tTglbayar, String tIdpel, String tBlth, String tNorek) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql =" select BLTH, IDPEL, NOPEL, KDGERAKMASUK, UPLOADTIME, UPLOADBY, KDGERAKKELUAR, TGLBAYAR, WKTBAYAR, KDPP, KDPEMBAYAR, KDKOREKSI, TGKOREKSI, STATUS, KDPEMBPP, KDPEMBAYARSIP3, UNITUP, PEMDA, NAMA, PNJ, NAMAPNJ, NOBANG, KETNOBANG, RT, RW, NODLMRT, KETNODLMRT, LINGKUNGAN, KODEPOS, IDTARIP, TARIP, KDPEMBTRF, ABONMETER, DAYA, KDAYA, KOGOL, SUBKOGOL, FRT, FJN, KDPPJ, UNITKJ, KDINKASO, KDKELOMPOK, TGLJTTEMPO, KDDK, TGLBACA, SLALWBP, SAHLWBP, SLAWBP, SAHWBP, SLAKVARH, SAHKVARH, SKVAMAX, FAKM, FAKMKVARH, FAKMKVAMAX, KWHLWBP, KWHWBP, BLOK3, PEMKWH, KWHKVARH, KELBKVARH, RPLWBP, RPWBP, RPBLOK3, RPKVARH, RPBEBAN, CTTLB, RPTTLB, RPPTL, RPTB, RPPPN, RPBPJU, RPTRAFO, RPSEWATRAFO, RPSEWAKAP, KDANGSA, RPANGSA, KDANGSB, RPANGSB, KDANGSC, RPANGSC, RPMAT, RPPLN, RPTAG, RPPRODUKSI, RPSUBSIDI, RPREDUKSI, RPINSENTIF, RPDISINSENTIF, RPBK1, RPBK2, RPBK3, RPTDLLAMA, RPTDLBARU, RPSELISIH, NOREK, NOAGENDA, FLAGSOPP, FLAGANJA, KDKIRIM, KDTERIMA, TGLKONSLD, KONSLDKE, UPDATEBY, UPDATETIME ";
            sql = " ,BPAKAI1,BPAKAI2,BPAKAI3,BKVAR ";
            sql = " from VIEW_CETAKREKG_233132_TFORM ";
            sql = " where ";
            sql = " idpel = '" + tIdpel + "' ";
            sql = " and tglbayar = '" + tTglbayar + "' ";
            sql = " and kdpembpp = 'R1' ";
            sql = " and kdgerakkeluar = '23' ";
            sql = " and blth = '" + tBlth + "' ";
            sql = " and norek = '" + tNorek + "' ";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("cetakRekg23", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    Map<String, Object> cetakRekg31(String tTglbayar, String tIdpel, String tBlth, String tNorek) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = " select BLTH, IDPEL, NOPEL, KDGERAKMASUK, UPLOADTIME, UPLOADBY, KDGERAKKELUAR, TGLBAYAR, WKTBAYAR, KDPP, KDPEMBAYAR, KDKOREKSI, TGKOREKSI, STATUS, KDPEMBPP, KDPEMBAYARSIP3, UNITUP, PEMDA, NAMA, PNJ, NAMAPNJ, NOBANG, KETNOBANG, RT, RW, NODLMRT, KETNODLMRT, LINGKUNGAN, KODEPOS, IDTARIP, TARIP, KDPEMBTRF, ABONMETER, DAYA, KDAYA, KOGOL, SUBKOGOL, FRT, FJN, KDPPJ, UNITKJ, KDINKASO, KDKELOMPOK, TGLJTTEMPO, KDDK, TGLBACA, SLALWBP, SAHLWBP, SLAWBP, SAHWBP, SLAKVARH, SAHKVARH, SKVAMAX, FAKM, FAKMKVARH, FAKMKVAMAX, KWHLWBP, KWHWBP, BLOK3, PEMKWH, KWHKVARH, KELBKVARH, RPLWBP, RPWBP, RPBLOK3, RPKVARH, RPBEBAN, CTTLB, RPTTLB, RPPTL, RPTB, RPPPN, RPBPJU, RPTRAFO, RPSEWATRAFO, RPSEWAKAP, KDANGSA, RPANGSA, KDANGSB, RPANGSB, KDANGSC, RPANGSC, RPMAT, RPPLN, RPTAG, RPPRODUKSI, RPSUBSIDI, RPREDUKSI, RPINSENTIF, RPDISINSENTIF, RPBK1, RPBK2, RPBK3, RPTDLLAMA, RPTDLBARU, RPSELISIH, NOREK, NOAGENDA, FLAGSOPP, FLAGANJA, KDKIRIM, KDTERIMA, TGLKONSLD, KONSLDKE, UPDATEBY, UPDATETIME ";
            sql = " ,BPAKAI1,BPAKAI2,BPAKAI3,BKVAR ";
            sql = " from VIEW_CETAKREKG_233132_TFORM ";
            String Sql = " where ";
            Sql = " idpel = '" + tIdpel + "' ";
            Sql = " and tglbayar = '" + tTglbayar + "' ";
            Sql = " and kdpembpp = 'R1' ";
            Sql = " and kdgerakkeluar = '31' ";
            Sql = " and blth = '" + tBlth + "' ";
            Sql = " and norek = '" + tNorek + "' ";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("cetakRekg31", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    Map<String, Object> cetakRekg32(String tTglbayar, String tIdpel, String tBlth, String tNorek) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = " select BLTH, IDPEL, NOPEL, KDGERAKMASUK, UPLOADTIME, UPLOADBY, KDGERAKKELUAR, TGLBAYAR, WKTBAYAR, KDPP, KDPEMBAYAR, KDKOREKSI, TGKOREKSI, STATUS, KDPEMBPP, KDPEMBAYARSIP3, UNITUP, PEMDA, NAMA, PNJ, NAMAPNJ, NOBANG, KETNOBANG, RT, RW, NODLMRT, KETNODLMRT, LINGKUNGAN, KODEPOS, IDTARIP, TARIP, KDPEMBTRF, ABONMETER, DAYA, KDAYA, KOGOL, SUBKOGOL, FRT, FJN, KDPPJ, UNITKJ, KDINKASO, KDKELOMPOK, TGLJTTEMPO, KDDK, TGLBACA, SLALWBP, SAHLWBP, SLAWBP, SAHWBP, SLAKVARH, SAHKVARH, SKVAMAX, FAKM, FAKMKVARH, FAKMKVAMAX, KWHLWBP, KWHWBP, BLOK3, PEMKWH, KWHKVARH, KELBKVARH, RPLWBP, RPWBP, RPBLOK3, RPKVARH, RPBEBAN, CTTLB, RPTTLB, RPPTL, RPTB, RPPPN, RPBPJU, RPTRAFO, RPSEWATRAFO, RPSEWAKAP, KDANGSA, RPANGSA, KDANGSB, RPANGSB, KDANGSC, RPANGSC, RPMAT, RPPLN, RPTAG, RPPRODUKSI, RPSUBSIDI, RPREDUKSI, RPINSENTIF, RPDISINSENTIF, RPBK1, RPBK2, RPBK3, RPTDLLAMA, RPTDLBARU, RPSELISIH, NOREK, NOAGENDA, FLAGSOPP, FLAGANJA, KDKIRIM, KDTERIMA, TGLKONSLD, KONSLDKE, UPDATEBY, UPDATETIME ";
            sql = " ,BPAKAI1,BPAKAI2,BPAKAI3,BKVAR ";
            sql = " from VIEW_CETAKREKG_233132_TFORM ";
            String Sql = " where ";
            Sql = " idpel = '" + tIdpel + "' ";
            Sql = " and tglbayar = '" + tTglbayar + "' ";
            Sql = " and kdpembpp = 'R1' ";
            Sql = " and kdgerakkeluar = '32' ";
            Sql = " and blth = '" + tBlth + "' ";
            Sql = " and norek = '" + tNorek + "' ";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put(" cetakRekg32", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    Map<String, Object> cetakRekg21(String tTglbayar, String tIdpel, String tBlth, String tNorek) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = " select BLTH, IDPEL, NOPEL, KDGERAKMASUK, UPLOADTIME, UPLOADBY, KDGERAKKELUAR, TGLBAYAR, WKTBAYAR, KDPP, KDPEMBAYAR, KDKOREKSI, TGKOREKSI, STATUS, KDPEMBPP, KDPEMBAYARSIP3, UNITUP, PEMDA, NAMA, PNJ, NAMAPNJ, NOBANG, KETNOBANG, RT, RW, NODLMRT, KETNODLMRT, LINGKUNGAN, KODEPOS, IDTARIP, TARIP, KDPEMBTRF, ABONMETER, DAYA, KDAYA, KOGOL, SUBKOGOL, FRT, FJN, KDPPJ, UNITKJ, KDINKASO, KDKELOMPOK, TGLJTTEMPO, KDDK, TGLBACA, SLALWBP, SAHLWBP, SLAWBP, SAHWBP, SLAKVARH, SAHKVARH, SKVAMAX, FAKM, FAKMKVARH, FAKMKVAMAX, KWHLWBP, KWHWBP, BLOK3, PEMKWH, KWHKVARH, KELBKVARH, RPLWBP, RPWBP, RPBLOK3, RPKVARH, RPBEBAN, CTTLB, RPTTLB, RPPTL, RPTB, RPPPN, RPBPJU, RPTRAFO, RPSEWATRAFO, RPSEWAKAP, KDANGSA, RPANGSA, KDANGSB, RPANGSB, KDANGSC, RPANGSC, RPMAT, RPPLN, RPTAG, RPPRODUKSI, RPSUBSIDI, RPREDUKSI, RPINSENTIF, RPDISINSENTIF, RPBK1, RPBK2, RPBK3, RPTDLLAMA, RPTDLBARU, RPSELISIH, NOREK, NOAGENDA, FLAGSOPP, FLAGANJA, KDKIRIM, KDTERIMA, TGLKONSLD, KONSLDKE, UPDATEBY, UPDATETIME ";
            sql = " ,BPAKAI1,BPAKAI2,BPAKAI3,BKVAR ";
            sql = " from VIEW_CETAKREKG_21_TFORM ";
            sql = " where ";
            sql = " idpel = '" + tIdpel + "' " ;
            sql = " and tglbayar = '" + tTglbayar + "' ";
            sql = " and kdpembpp = 'R1' ";
            sql = " and kdgerakkeluar = '21' ";
            sql = " and blth = '" + tBlth + "' ";
            sql = " and norek = '" + tNorek + "' ";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("cetakRekg21", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    Map<String, Object> cetakRekg21Giralisasi(String tTglBayar,
                                              String tKDPP,
                                              String tKodeGiral) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "SELECT * ";
            sql = " from VIEW_CETAK303_LUNASGIRAL ";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("cetakRekg21Giralisasi", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    Map<String, Object> cetakRekg21NotaBuku(String tKodePetugas,
                                            String tKodeNota, String tUnitup) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql =" SELECT * ";
            sql = " from VIEW_CETAK303_LUNASNOTA ";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put(" cetakRekg21NotaBuku", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    Map<String, Object> cetakRekg21NotaTerpusat(String tKodePetugas,
                                                String tKodeNota,
                                                String tUnitup) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql =" SELECT * ";
            sql = " from VIEW_CETAK303_LUNASTERPUSAT ";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("cetakRekg21NotaTerpusat", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    Map<String, Object> cetakRekg21EntriLunas(String tKodePetugas,
                                              String tIDPEL,
                                              String tBLTH) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql =" SELECT * ";
            sql = " from VIEW_CETAK303_LUNASENTRI ";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("cetakRekg21EntriLunas", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    Map<String, Object> getCetul_21Giralisasi(String strPetugas,
                                              String sKodeKolektif, String sTglLunas,
                                              String sKDPP) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql =" getCetul_21Giralisasi";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("getCetul_21Giralisasi", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    Map<String, Object> SetCetul_21Giralisasi(Map<String, Object> dsTrans) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="SetCetul_21Giralisasi";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("SetCetul_21Giralisasi", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    Map<String, Object> getCetul_23NotaBuku(String strPetugas,
                                            String sKodeKolektif,
                                            String sTglLunas, String tUnitup) {
        cls_CetakUlang func = new cls_CetakUlang();
        Map<String, Object> retFunc = func.getCetul_23NotaBuku(strPetugas, sKodeKolektif, sTglLunas, tUnitup);
        return retFunc;

//        Map<String, Object> retValue = new HashMap<String, Object>();
//        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();
//
//        try
//        {
//            cls_CetakUlang func = new cls_CetakUlang();
//            Map<String, Object> retFunc = func.getCetul_23NotaBuku(strPetugas, sKodeKolektif, sTglLunas, tUnitup);
//
//
//            Connection con = jdbcTemplate.getDataSource().getConnection();
//
//            String sql =" getCetul_23NotaBuku";
//
//            CallableStatement cst;
//            cst = con.prepareCall(sql);
//
//            ResultSet rs = cst.executeQuery();
//
//            lMapPetugas = CommonModule.convertResultsetToListStr(rs);
//
//            retValue.put(" getCetul_23NotaBuku", lMapPetugas);
//
//            con.close();
//        } catch (Exception ex)
//        {
//            ex.printStackTrace();
//        }
//        return retValue;
    }

    Map<String, Object> SetCetul_23NotaBuku(Map<String, Object> dsTrans) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql =" SetCetul_23NotaBuku";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("SetCetul_23NotaBuku", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    Map<String, Object> getCetul_23Terpusat(String strPetugas,
                                            String sKodeKolektif, String sTglLunas,
                                            String sUnitup) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="getCetul_23Terpusat";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("getCetul_23Terpusat", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    Map<String, Object> SetCetul_23Perpusat(Map<String, Object> dsTrans) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="SetCetul_23Perpusat";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("SetCetul_23Perpusat", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }
}
