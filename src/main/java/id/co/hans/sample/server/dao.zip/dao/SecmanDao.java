package id.co.hans.sample.server.dao;

import java.util.List;
import java.util.Map;

public interface SecmanDao {
	public  List<Map<String, String>> getUserMenuByIdsesion(String idSesion, String page);
}
