package id.co.hans.sample.server.dao;

public class clsKODE_GERAK {
    public String KODE_GERAK;
    public String KETERANGAN;
    public String GERAK_PIUTANG;
}
