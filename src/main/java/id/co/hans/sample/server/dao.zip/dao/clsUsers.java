package id.co.hans.sample.server.dao;

public class clsUsers {
    public String KODEPETUGAS;
    public String KELAMIN;
    public String SK;
    public String NIP;
    public String NAMAPETUGAS;
    public String KODEPP;
    public String PASSWORD;
    public String ROLEID;
    public String UNITUP;
    public String ALAMAT;
    public String FROMDATE;
    public String THRUDATE;
    public String PETUGAS_CATAT;
    public String RIGHTSLOGIN;
}
