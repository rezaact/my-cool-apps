package id.co.hans.sample.server.dao.impl;

import id.co.hans.sample.server.dao.SecmanDao;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class SecmanDaoImpl implements SecmanDao{

    @Override
    public Map<String, Object> getUserMenuByIdsesion(String idSesion, String page) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
