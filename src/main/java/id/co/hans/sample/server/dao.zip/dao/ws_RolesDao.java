package id.co.hans.sample.server.dao;

import java.util.Map;

public interface ws_RolesDao {
    public Map<String, Object> GetRolesMenus(Integer RoleID);
    public Map<String, Object> GetMenus();
    public Map<String, Object> GetRoles();
    public Map<String, Object> UpdateRoles(Integer RoleID, Map<String, Object> arr);
}
