package id.co.hans.sample.server.dao.impl;


import id.co.hans.sample.server.utility.CommonModule;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.*;

public class ws_InterfaceDaoImpl {
    public static final Log log = LogFactory.getLog(ws_InterfaceDaoImpl.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;
    public Map<String, Object> simpanDPHLoad_AJN(String idPel,
                                                 String blth,
                                                 String tglbayar,
                                                 String rptag,
                                                 String rpbk,
                                                 String ipaddress) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "select * from sip3user.DPP where idpel='" + idPel + "'  and blth='" + blth + "'";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("simpanDPHLoad_AJN", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> simpanDPHLoads(String idPel,
                                              String blth,
                                              String kdpembpp,
                                              String unitup,
                                              String kdpp,
                                              String kdgerak,
                                              String tglbayar,
                                              String refno,
                                              String rptag,
                                              String rpbk,
                                              String layerke,
                                              String ipaddress,
                                              String tglupload,
                                              String noupload) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "insert into sip3user.dph_load (idPel,blth,kdpembpp,unitup,kdpp,kdgerak,tglbayar,jambayar,refno,rptag,rpbk,layerke,ipaddress,tglupload,noupload) ";
            String strquery = "insert into sip3user.dph_load (idPel,blth,kdpembpp,unitup,kdpp,kdgerak,tglbayar,jambayar,refno,rptag,rpbk,layerke,ipaddress,tglkonsld,konsldke) ";
            strquery += "values ('" + idPel + "','" + blth + "','" + kdpembpp + "',";
            strquery += "'" + unitup + "','" + kdpp + "','" + kdgerak + "'";
            strquery += ",to_char(sysdate,'ddmmyyyy'),'" ;
            strquery += "'','" + rptag + "','" + rpbk + "',";
            strquery += "'" + layerke + "','" + ipaddress + "',tRUNC(" + tglupload + "),'" + uploadKe("DPH") + "')";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("simpanDPHLoads", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> simpandphload_2(String idPel,
                                               String kdpembpp,
                                               String unitup,
                                               String kdpp,
                                               String kdgerak,
                                               String refno,
                                               String rpbk,
                                               String layerke,
                                               String ipaddress,
                                               String noupload,
                                               Integer type_rekening) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="select no_pelanggan,uraian as blth,sum(mutasi) as rptag from dis ";
            String str = "where no_pelanggan='" + idPel + "' ";
            str += " and tgl_pelunasan=trunc(sysdate) ";
            str += " group by no_pelanggan,uraian";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("simpandphload_2", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> simpanddphload_Kolektif(String kdpembpp,
                                                       String unitup,
                                                       String kdpp,
                                                       String kdgerak,
                                                       String refno,
                                                       String rpbk,
                                                       String layerke,
                                                       String ipaddress,
                                                       String noupload,
                                                       String kdkol) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="select a.no_pelanggan,a.uraian as blth,sum(a.mutasi) as rptag from dis a, temptul504kolektif b ";
            String str = " where a.tgl_pelunasan=trunc(sysdate) ";
            str += " and a.NO_PELANGGAN = b.NO_PELANGGAN ";
            str += " and UPPER(b.kodekolektif) = '" ;
            str += " group by a.no_pelanggan,a.uraian ";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("simpanddphload_Kolektif", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }

    public Map<String, Object> bl_th_tagihan(String blthrek) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="bl_th_tagihan" ;

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("bl_th_tagihan", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> fg_tgl_jatuh_tempo(String blth,
                                                  String kode_ranting_numerik) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="select tanggal from refverifikasi where kode_ranting_numerik='" ;

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("fg_tgl_jatuh_tempo", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> getData(String strQuery) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="getData" ;

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("getData", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> setData(String strQuery) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="setData" ;

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("setData", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> isiDKRPLoad(String no_pelanggan,
                                           String uraian,
                                           String ipaddress,
                                           String tglkonsld,
                                           Integer konsldke,
                                           Integer layerke) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="isiDKRPLoad " ;

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("isiDKRPLoad", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> rptBaOffline(String TglLunas,
                                            String petugas) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="insert into temp_baoffline " ;
            String str = "(LBRMSL,LBRLANCAR,LBRTUNG,RPDISJALAN,RPMSL,RPdisTUNG,TOTPLGN,TOTRP,TGL_PELUNASAN,PTGS,KODE_GOLONGAN,PTGS_CTK) ";
            str += "select ";
            str += " LBRMSL,LBRLANCAR,LBRTUNG,RPDISJALAN,RPMSL,RPdisTUNG,TOTPLGN,TOTRP,TGL_PELUNASAN,PTGS,KODE_GOLONGAN,'" + petugas + "' ";
            str += "from v_baoffline";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("rptBaOffline", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> rptRkpPelunasanHarian(String tglmulai,
                                                     String tglselesai,
                                                     String petugas) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="rptRkpPelunasanHarian " ;

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("rptRkpPelunasanHarian", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> rptRkpPelunasanPeriode(String tglmulai,
                                                      String tglselesai, String petugas) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="rptRkpPelunasanPeriode " ;

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("rptRkpPelunasanPeriode", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> simpanDPHLoad(String idPel,
                                             String blth,
                                             String kdpembpp,
                                             String unitup,
                                             String kdpp,
                                             String kdgerak,
                                             String tglbayar,
                                             String refno,
                                             String rptag,
                                             String rpbk,
                                             String layerke,
                                             String ipaddress,
                                             String tglupload,
                                             String noupload) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="\"insert into dph_load (idPel,blth,kdpembpp,unitup,kdpp,kdgerak,tglbayar,jambayar,refno,rptag,rpbk,layerke,ipaddress,tglupload,noupload) \" " ;
            String strquery = "values ('" + idPel + "','" + blth + "','" + kdpembpp + "',";
            strquery += "'" + unitup + "','" + kdpp + "','" + kdgerak + "'";
            strquery += ",'" + tglbayar + "','" ;
            strquery += "'" + refno + "','" + rptag + "','" + rpbk + "',";
            strquery += "'" + layerke + "','" + ipaddress + "'," + tglupload + ",'" + uploadKe("DPH") + "')";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("simpanDPHLoad", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> simpanDpdtLoad(String idpel,
                                              String blth,
                                              String kdkoreksi,
                                              String ipaddress,
                                              String KRM,
                                              String TRM) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="select * from sip3user.dpp where idpel='" + idpel + "' and blth='" + blth + "'" ;

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("simpanDpdtLoad", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }

    public Map<String, Object> simpanDpdtLoadTERIMA(String idpel,
                                                    String ur) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="select * from dil where no_pelanggan='" + idpel + "'" ;

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("simpanDpdtLoadTERIMA", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> simpanDKRPLoadS(String no_pelanggan,
                                               String blth,
                                               String URAIAN,
                                               String ipaddress,
                                               String kodegerak) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="select no_pelanggan,uraian , mutasi,nmpiutang,tgl_jatuh_tempo " ;
            String strquery = " from dis where no_pelanggan='" + no_pelanggan + "' and uraian='" + URAIAN + "'";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("simpanDpdtLoadTERIMA", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> simpanDKRPLoad(String idpel,
                                              String blth,
                                              String kdkoreksi,
                                              String ipaddress) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="select * from sip3user.dpp where idpel='" + idpel + "' and blth='" + blth + "'" ;

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("simpanDKRPLoad", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> simpandkrpload_Krk_kd_golongan(String kdkol,
                                                              String ipaddress) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="select a.no_pelanggan,a.uraian as blth,sum(a.mutasi) as rptag from dis a, temptul504kolektif b " ;
            String str = " where a.NO_PELANGGAN = b.NO_PELANGGAN ";
            str += " and UPPER(b.kodekolektif) = '"; // + kdkol.ToUpper + "' ";
            str += " group by a.no_pelanggan,a.uraian ";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("simpanDKRPLoad", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> simpanDKRPL(String idpel,
                                           String no_kwitansi,
                                           String IPADDRESS) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="select * from sip3user.dpp where idpel='"; // + idpel + "' " 'and blth='" + blth + "'" ;

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("simpanDKRPL", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    Map<String, Object> simpanDBPLoad(String nopelanggan,
                                      String blth,
                                      String ipaddress,
                                      String kodegerak) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="select * from sip3user.dpp where idpel='"; // + nopelanggan + "' " 'and blth='" + blth + "'" ;

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("simpanDBPLoad", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    Map<String, Object> uploadKe(String jenisdata) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="select max(konsldke) from sip3user.log_upload where tgljamupload=to_date(sysdate,'dd-mm-yyyy') and jenisdata='"; // + jenisdata + "'" ;

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("uploadKe", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    Map<String, Object> uploadKeAJN() {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="select max(konsldke) from sip3user.dph_load where tglkonsld=to_date(sysdate,'dd-mm-yyyy') " ;

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("uploadKeAJN", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    Map<String, Object> kodeKoreksi(String alasan) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="kodeKoreksi " ;

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("kodeKoreksi", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> bl_th(String blth) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="bl_th " ;

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("bl_th", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> setRek_Sorek(String procedureName,
                                            String unitup,
                                            String blth) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="INSERT INTO SIP3user.SOREK_LOAD " ;
            String str = " (UNITUP,KDPEMBAYAR,IDPEL,blth,KDPP,TGLBAYAR,PEMDA";
            str += ",NAMA,PNJ,NAMAPNJ,NOBANG,KETNOBANG,RT,RW,NODLMRT";
            str += ",KETNODLMRT,LINGKUNGAN,KODEPOS,TARIP,DAYA,KDAYA,KOGOL";
            str += ",NOPEL,FRT,KDDK,TGLBACA,SLALWBP,SAHLWBP,SLAWBP,SAHWBP,SLAKVARH";
            str += ",SAHKVARH,FAKM,FAKMKVARH,KWHLWBP,KWHWBP,BLOK3,PEMKWH";
            str += ",KWHKVARH,RPLWBP,RPWBP,RPBLOK3,RPKVARH,RPBEBAN,CTTLB,RPTTLB,RPPTL" ;
            str += ",RPTB,RPPPN,RPBPJU,RPTRAFO,KDANGSA,RPANGSA,KDANGSB,RPANGSB,KDANGSC";
            str += ",RPANGSC,RPMAT,RPPLN,RPTAG,RPPRODUKSI,RPSUBSIDI,TGLJTTEMPO,RPBK1,RPBK2";
            str += ",RPBK3,KDGERAK,STATUS,KDKOREKSI,TGKOREKSI,KDPEMBPP,RPTDLLAMA";
            str += ",RPTDLBARU,RPSELISIH,RPREDUKSI,NOREK,ALAMAT,KDPPJ,KELOMPOK,JNSMUT";
            str += ",BLTHMUT,KDMUT,TGLNYALA, KDAM,NOGARDU,NOTIANG,RPSEWAKAP,KWHBLOK1";
            str += ",KWHBLOK2,RPBLOK1,RPBLOK2,RPDISKON,TRPBEBAN,TRPBLOK1,TRPBLOK2,TRPBLOK3,TRPLWBP";
            str += ",TRPWBP,TRPKVARH,TGLKONSLD,KONSLDKE,IPADDRESS,LAYERKE) ";
            str += "SELECT ";
            str += "UNIT ";
            str += ",KDPEMBAYAR";
            str += ",IDPEL";
            str += ",SUBSTR(BLTHREK,5,2)||SUBSTR(BLTHREK,1,4) "; // 'blth;
            str += ",KDPP" ;
            str += ",NULL "; // 'TGLBAYAR";
            str += ",KDPEMDA "; // 'PEMDA";
            str += ",SUBSTR(NAMA,1,25)";
            str += ",PNJ";
            str += ",NAMAPNJ";
            str += ",NOBANG";
            str += ",NULL "; // 'KETNOBANG";
            str += ",RT";
            str += ",RW";
            str += ",NODLMRT";
            str += ",KETNODLMRT";
            str += ",LINGKUNGAN";
            str += ",NULL "; // 'KODEPOS";
            str += ",TARIP";
            str += ",DAYA";
            str += ",KDDAYA "; // 'KDAYA";
            str += ",KDGOL "; // 'KOGOL";
            str += ",SUBSTR(IDPEL,1,11) "; // 'NOPEL";
            str += ",FRT";
            str += ",KDDK";
            str += ",TO_CHAR(TGLBACA,'ddmmyyyy')";
            str += ",SLALWBP";
            str += ",SAHLWBP";
            str += ",SLAWBP";
            str += ",SAHWBP";
            str += ",SLAKVARH" ;
            str += ",SAHKVARH";
            str += ",FAKM";
            str += ",FAKMKVARH";
            str += ",KWHLWBP";
            str += ",KWHWBP";
            str += ",KWHBLOK3 "; // 'BLOK3";
            str += ",KWHLWBP+KWHWBP+KWHBLOK1+KWHBLOK2+KWHBLOK3 "; // 'PEMKWH" ;
            str += ",KWHKVARH";
            str += ",RPLWBP";
            str += ",RPWBP";
            str += ",RPBLOK3";
            str += ",RPKVARH";
            str += ",RPBEBAN";
            str += ",NULL "; // 'CTTLB" ;
            str += ",0 "; // 'RPTTLB" ;
            str += ",RPPTL";
            str += ",0 "; // 'RPTB";
            str += ",RPPPN";
            str += ",RPPJU "; // 'RPBPJU";
            str += ",RPSEWATRF "; // 'RPTRAFO";
            str += ",KDANGSA";
            str += ",RPANGSA";
            str += ",KDANGSB";
            str += ",RPANGSB";
            str += ",KDANGSC";
            str += ",RPANGSC";
            str += ",RPMAT";
            str += ",RPPLN";
            str += ",RPTAG";
            str += ",RPRDUKSI "; // 'RPPRODUKSI";
            str += ",0 "; // 'RPSUBSIDI";
            str += ", TO_CHAR(TRUNC(LAST_DAY(TO_DATE(BLTHREK,'YYYYMM'))),'DDMMYYYY') "; // 'TGLJTTEMPO" ;
            str += ",RPBK " ; //'RPBK1" ;
            str += ",0 "; // 'RPBK2";
            str += ",0 "; // 'RPBK3" ;
            str += ",'11' "; // 'KDGERAK";
            str += ",'L' "; // 'STATUS";
            str += ",NULL "; // 'KDKOREKSI";
            str += ",NULL "; // 'TGKOREKSI";
            str += ",'R1' "; // 'KDPEMBPP";
            str += ",0 "; // 'RPTDLLAMA";
            str += ",0 " ; //'RPTDLBARU";
            str += ",0 "; // 'RPSELISIH";
            str += ",RPDISKON " ; //'RPREDUKSI";
            str += ",'XXXXXX' "; // 'NOREK" ;
            str += ",ALAMAT";
            str += ",KDPPJ";
            str += ",KELOMPOK";
            str += ",JNSMUT";
            str += ",BLTHMUT";
            str += ",KDMUT";
            str += ",TGLNYALA";
            str += ",KDAM";
            str += ",NOGARDU";
            str += ",NOTIANG";
            str += ",RPSEWAKAP";
            str += ",KWHBLOK1";
            str += ",KWHBLOK2";
            str += ",RPBLOK1";
            str += ",RPBLOK2";
            str += ",RPDISKON";
            str += ",TRPBEBAN";
            str += ",TRPBLOK1";
            str += ",TRPBLOK2";
            str += ",TRPBLOK3";
            str += ",TRPLWBP";
            str += ",TRPWBP";
            str += ",TRPKVARH";
            str += ",TRUNC(SYSDATE)"; // 'TGLKONSLD" ;
            str += ",'1' KONSLDKE";
            str += ",'10.4.130.23' "; // 'IPADDRESS";
            str += ",1 "; // 'LAYERKE ";
            str += "FROM BILLING."; // + namatabel + "" ;
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("setRek_Sorek", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }

    public Map<String, Object> setLunas(String petugas) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="update dis set lunas='Lunas' ," ;
            String str = "tgl_pelunasan=tgl_jatuh_tempo,cetak='YA',";
            str += "kode_gerak_keluar=29,kodepetugas='"; // + petugas + "', ";
            str += "jenis_pp='OFFLINE' where lunas is null ";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("setLunas", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> setSaldo(String baris_txt) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="insert into saldo_awal (blthsaldo,no_pelanggan,blthrek,rptag) " ;
            String str = "values ('"; // + item(2) + "','" + item(1) + "','" + getBlThRekening(item(2)) + "','" + item(3) + "')";
            setData(str);
            str = "update dis set lunas = null , tgl_pelunasan=null ,";
            str += "cetak=null,kode_gerak_keluar=null,kodepetugas=null ";
            str += ",jenis_pp=null where no_pelanggan='"; // + item(1) + "' ";
            str += "and uraian='"; // + getUraian(item(2)) + "' ";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("setSaldo", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> getUraian(String blth) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="getUraian " ;

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("getUraian", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> getBlThRekening(String blth) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="getBlThRekening " ;

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("getBlThRekening", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> cekrekbermasalah(String tgllunas,
                                                String idpel,
                                                String sbb) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="" ;
            sql = sql + " SELECT NO_PELANGGAN FROM rekeningbermasalah";
            sql = sql + " WHERE NO_PELANGGAN='" + idpel + "'";
            sql = sql + " AND PENYEBAB='" + sbb + "'";
            sql = sql + " AND to_char(tglpelunasan,'dd-mm-yyyy')='" + tgllunas + "'";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("cekrekbermasalah", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> setPelunasanOffline(String strread,
                                                   String strGlobalKodePetugas,
                                                   String ipaddress) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="SELECT No_pelanggan" ;
            String strSQL = null;
            strSQL = strSQL + " FROM DIS";
            strSQL = strSQL + " where No_Pelanggan = '"; // + strNoPelanggan + "'";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("setPelunasanOffline", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    //ADDED BY DJAINUL
    public Map<String, Object> InsertDPPfromSOREK(String CustomConnectionString,
                                                  String pUNITUP,
                                                  String pBLTH) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="InsertDPPfromSOREK" ;

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("InsertDPPfromSOREK", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> doRekapSOREK(String CustomConnectionString,
                                            String pUNITUP,
                                            Date pTGLKONSLD) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="doRekapSOREK" ;

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("doRekapSOREK", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> doRekapDPP(String CustomConnectionString,
                                          String pUNITUP,
                                          Date pTGLKONSLD) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapPetugas = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="doRekapDPP" ;

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapPetugas = CommonModule.convertResultsetToListStr(rs);

            retValue.put("doRekapDPP", lMapPetugas);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }
}
