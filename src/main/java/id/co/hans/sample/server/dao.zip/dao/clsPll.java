package id.co.hans.sample.server.dao;

public class clsPll {
    public String cTGL_TRANSAKSI = "";
    public String cNO_PELANGGAN = "";
    public String cNO_AGENDA = "";
    public Double cKWH = 0D;
    public String cKODE_PERKIRAAN_BARU = "";
    public String cPETUGAS = "";
    public String cLUNAS = "";
    public String cTGL_LUNAS = "";
    public String cJENIS_PLL = "";
    public Double cRP_PLL = 0D;
    public Double cRP_BEBAN = 0D;
    public Double cRP_UJL = 0D;
    public Double cRP_PPJU = 0D;
    public Double cRP_MATERAI = 0D;
    public Double cRP_MATERIAL = 0D;
    public Double cRP_ADMINISTRASI = 0D;
    public Double cRP_LAIN_LAIN = 0D;
    public String cKETERANGAN = "";
    public Double cKWH_WBP = 0D;
    public Double cKWH_LWBP = 0D;
    public Double cKWH_BLOK3 = 0D;
    public String cNOKWITANSI;
}
