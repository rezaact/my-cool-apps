package id.co.hans.sample.server.dao;

public class clsUNITAP {
    public String UNITAP;
    public String SATUAN;
    public String NAMA;
    public String ALAMAT;
    public String TELEPON;
    public String FAXIMILE;
    public String UNITUPI;
    public String MANAGER;
    public String KOTA;
}
