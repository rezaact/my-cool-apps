package id.co.hans.sample.server.dao.impl;


import id.co.hans.sample.server.dao.ws_PKDao;
import id.co.hans.sample.server.utility.CommonModule;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.*;

public class ws_PKDaoImpl {
    public static final Log log = LogFactory.getLog(ws_PKDaoImpl.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;
    public Map<String, Object> setSimpanCreditNote(String nocn,
                                                   Date tgl,
                                                   String kodebank,
                                                   String kodepp,
                                                   Double mutasi,
                                                   String kodePetugas,
                                                   String kb,
                                                   String blth) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "INSERT INTO CREDITNOTE(NO_CN,tgl_transaksi,mutasi,kode_bank,kodepp,kodepetugas,jenisbank" +
            ",blthrek) VALUES " +
            " ('" + nocn + "', TO_DATE('"; // + strTanggal + "','mm-dd-yyyy')," + mutasi + ",'" + kodebank + "','" + kodepp + "','" + kodePetugas + "','" + kb + "','" + blth + "')";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("setSimpanCreditNote", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }

    public Map<String, Object> getRanting(String strKodeCabang) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "SELECT Nama_Ranting, Kode_Cabang_Numerik, Kode_Ranting,Kode_Ranting_Numerik From RantingRayon Where Kode_Cabang_Numerik = '" + strKodeCabang + "' ORDER BY Nama_Ranting";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("getRanting", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }

    public Map<String, Object> getPP(String strKodeRanting) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "SELECT * From Payment_point Where kode_ranting_numerik = '" + strKodeRanting + "' ORDER BY namapp"; // + strKodeCabang + "' ORDER BY Nama_Ranting";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("getPP", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }

    public Map<String, Object> getInduk() {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "select Kode_Induk, Kode_Induk_Numerik, Nama_Induk  From Induk";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("getInduk", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }

    public Map<String, Object> getCabang() {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "SELECT Nama_Cabang, Kode_Cabang, Kode_cabang_Numerik, Kode_Induk_Numerik From cabang";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("getCabang", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> setVerifikasiPiutang(String strKodeInduk,
                                                    String strKodeCabang,
                                                    String strKodeRanting) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "setVerifikasiPiutang";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("setVerifikasiPiutang", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }

    public Map<String, Object> getBongkar(String Nomor,
                                          Byte bytTypeNo) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "SELECT * FROM TUL63, TUL61, DIL";
            String strSQL = null;
            strSQL = strSQL + " WHERE TUL63.NO_PELANGGAN=TUL61.NO_PELANGGAN AND ";
            strSQL = strSQL + " TUL63.NO_PELANGGAN=DIL.NO_PELANGGAN AND ";
            strSQL = strSQL + " TUL61.NOCETAKTUL601='"; // + Nomor + "' AND TUL63.TANGGAL_PELAKSANAAN is NULL";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("getBongkar", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }

    public Map<String, Object> setBongkar(String strNomor,
                                          String strPelaksana,
                                          String Byte,
                                          String NoPelanggan) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "update TUL63";
            String strSQL = null; // + tgl + "','mm-dd-yyyy'),";
            strSQL = strSQL + " set Tanggal_Pelaksanaan = TO_DATE('";
            strSQL = strSQL + " Nama_Pelaksana='" + strPelaksana + "', ";
            strSQL = strSQL + " TUL63.NOCETAKTUL603='" + strNomor + "'";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("setBongkar", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }

    public Map<String, Object> getTusBung(String Nomor,
                                          Byte bytType,
                                          Byte bytTypeNo) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "SELECT *";
            String strSQL = null;
            strSQL = strSQL + " FROM TUL62,dil";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("getTusBung", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }

    public Map<String, Object> setTusBung(String strNomor,
                                          String strPelaksana,
                                          String strWBP,
                                          String strLWBP,
                                          String strKVARH,
                                          Byte bytType,
                                          String bytTypeNo) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "update TUL62";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("setTusBung", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> getCustomer(String strNomor,
                                           Byte bytType) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "SELECT No_Pelanggan,No_Kontrak,Nama_Pelanggan,Tarip,Daya,Jalan,Nama_Jalan,No_Bangunan,";
            String strSQL = null;
            strSQL = strSQL + " Kodya_Kabupaten,Kode_pos,Telepon FROM DIL ";
            strSQL = strSQL + " Where DIL.No_Kontrak = '" + strNomor + "'";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("getCustomer", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> formatINDO(Date strTgl) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "formatINDO";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("formatINDO", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> getMasterInduk() {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "SELECT * From Induk";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("getMasterInduk", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }

    public Map<String, Object> setMasterInduk(Map<String, Object> dsChanged) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "SELECT Kode_Induk, Kode_Cabang, Kode_Ranting, Kategori, Tahun, Bulan, Tanggal FROM REFVERIFIKASI";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("setMasterInduk", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }

    public Map<String, Object> getTablePejabat(String strKode) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "SELECT * From Pejabat";
            String strSQL = null;
            strSQL = strSQL + " where kd_pejabat='" + strKode + "'";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("getTablePejabat", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> getData(String strQuery) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "getData";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("getData", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;    }

    public Map<String, Object> setData(String strQuery) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "setData";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("setData", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }

    public Map<String, Object> CekPenghapusanTUL63(String strKodeRanting) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "SELECT TUL63.No_Pelanggan,TUL63.No_Kontrak,";
            String strSQL = null;
            strSQL = strSQL + " Tul63.No_tul60,";
            strSQL = strSQL + " max(dis.tgl_pelunasan)as Tanggal";
            strSQL = strSQL + " FROM TUL63 ";
            strSQL = strSQL + " inner join dil on TUL63.No_Pelanggan=DIL.No_Pelanggan ";
            strSQL = strSQL + " inner join dis";
            strSQL = strSQL + " on TUL63.No_Pelanggan=DIS.No_Pelanggan ";
            strSQL = strSQL + " where DIL.Kode_Ranting_Numerik='" + strKodeRanting + "'";
            strSQL = strSQL + " and dis.Lunas ='Lunas'";
            strSQL = strSQL + " and dis.NmPiutang='Biaya Keterlambatan'";
            strSQL = strSQL + " and dis.uraian='BK III'";
            strSQL = strSQL + " GROUP BY TUL63.No_Pelanggan,TUL63.No_Kontrak,";
            strSQL = strSQL + " Tul63.No_tul60";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("CekPenghapusanTUL63", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }

    public Map<String, Object> CekPenghapusanTUL62(String strKodeRanting) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "SELECT TUL62.No_Pelanggan,TUL62.No_Kontrak,";
            String strSQL = null;
            strSQL = strSQL + " TUL62.No_tul60,";
            strSQL = strSQL + " dis.tgl_pelunasan";
            strSQL = strSQL + " FROM TUL62 ";
            strSQL = strSQL + " inner join dil on TUL62.No_Pelanggan=DIL.No_Pelanggan ";
            strSQL = strSQL + " inner join dis";
            strSQL = strSQL + " on TUL62.No_Pelanggan=DIS.No_Pelanggan ";
            strSQL = strSQL + " where DIL.Kode_Ranting_Numerik='" + strKodeRanting + "'";
            strSQL = strSQL + " and dis.Lunas ='Lunas'";
            strSQL = strSQL + " and dis.NmPiutang='Biaya Keterlambatan'";
            strSQL = strSQL + " and dis.uraian='BK I'";
            strSQL = strSQL + " GROUP BY TUL62.No_Pelanggan,TUL62.No_Kontrak,";
            strSQL = strSQL + " TUL62.No_tul60, dis.tgl_pelunasan";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("CekPenghapusanTUL62", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }

    public Map<String, Object> CekPenghapusanTUL61(String strKodeRanting) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "SELECT TUL61.No_Pelanggan,TUL61.No_Kontrak,";
            String strSQL = null;
            strSQL = strSQL + " TUL61.No_tul60,";
            strSQL = strSQL + " max(dis.tgl_pelunasan)as Tanggal ";
            strSQL = strSQL + " FROM TUL61 ";
            strSQL = strSQL + " inner join dil on TUL61.No_Pelanggan=DIL.No_Pelanggan ";
            strSQL = strSQL + " inner join dis ";
            strSQL = strSQL + " on TUL61.No_Pelanggan=DIS.No_Pelanggan ";
            strSQL = strSQL + " where DIL.Kode_Ranting_Numerik='" + strKodeRanting + "'";
            strSQL = strSQL + " and dis.Lunas ='Lunas'";
            strSQL = strSQL + " and dis.NmPiutang='Biaya Keterlambatan'";
            strSQL = strSQL + " and dis.uraian='BK I'";
            strSQL = strSQL + " GROUP BY TUL61.No_Pelanggan,TUL61.No_Kontrak,";
            strSQL = strSQL + " TUL61.No_tul60";
            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("CekPenghapusanTUL61", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }

    public Map<String, Object> setTUL61(String strKodeInduk,
                                        String strKodeCabang,
                                        String strKodeRanting) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "Select refTUL61.*, TO_CHAR(SYSDATE,'YYYY') as Thn,TO_CHAR(SYSDATE,'MM') as BLN  FROM refTUL61";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("setTUL61", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }

    public Map<String, Object> SetTUL62(String strKodeInduk,
                                        String strKodeCabang,
                                        String strKodeRanting) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="Select refTUL61.*, TO_CHAR(SYSDATE,'YYYY') as Thn,TO_CHAR(SYSDATE,'MM') as BLN  FROM refTUL61";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("SetTUL62", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }

    public Map<String, Object> SetTUL63(String strKodeInduk,
                                        String strKodeCabang,
                                        String strKodeRanting) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql ="Select refTUL61.*, TO_CHAR(SYSDATE,'YYYY') as Thn,TO_CHAR(SYSDATE,'MM') as BLN  FROM refTUL61";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("SetTUL63", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }

    public Map<String, Object> IsiTULVILAPORANSemuaTunggakan(String strKodeRanting) {
        Map<String, Object> retValue = new HashMap<String, Object>();
        List<Map<String,String>> lMapRecords = new ArrayList<Map<String,String>>();

        try
        {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "Delete TULVILaporanSemuaTunggakan";

            CallableStatement cst;
            cst = con.prepareCall(sql);

            ResultSet rs = cst.executeQuery();

            lMapRecords = CommonModule.convertResultsetToListStr(rs);

            retValue.put("IsiTULVILAPORANSemuaTunggakan", lMapRecords);

            con.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return retValue;     }
}
