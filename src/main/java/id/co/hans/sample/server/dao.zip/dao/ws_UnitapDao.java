package id.co.hans.sample.server.dao;

import java.util.Map;

public interface ws_UnitapDao {

    
    public Map<String, Object> GetUNITAP();
    
    public String InsertUNITAP(clsUNITAP UNITAP);
    public String UpdateUNITAP(clsUNITAP UNITAP);
    public String DeleteUNITAP(clsUNITAP UNITAP);
    
}
